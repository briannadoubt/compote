CompoteCommand.main()
